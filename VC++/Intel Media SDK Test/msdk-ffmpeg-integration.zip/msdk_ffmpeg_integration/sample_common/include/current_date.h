
#define CURRENT_DATE "Build_2012/8/4"

#define PRODUCT_NAME "Intel� Media SDK"

#define FILE_VERSION 3,12,8,4

#define FILE_VERSION_STRING "3,12,8,4"

#define FILTER_NAME_PREFIX "Intel� Media SDK"

#define FILTER_NAME_SUFFIX ""

#define PRODUCT_COPYRIGHT "Copyright� 2003-2012 Intel Corporation"

#define PRODUCT_VERSION 3,5,915,0

#define PRODUCT_VERSION_STRING "3,5,915,0"
