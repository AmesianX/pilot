# include "stdio.h"
# define U(x) ((x)&0377)
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern unsigned char yytext[];
int yymorfg;
extern unsigned char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
	Mini-pascal LEX input file for pp.121-125
#include <stdio.h>
#include <stdlib.h>

enum tnumber {
	TEOF, TIDENT, TNUMBER, TPLUS, TMINUS, TTIMES,
	TCOMMA, TSEMICOLON, TCOLON, TASSIGN, TDOT, TDDOT,
	TLPAREN, TRPAREN, TLBRACKET, TRBRACKET, TEQUAL, TNEQUAL,
	TLESS, TLESSE, TGREAT, TGREATE,
	ARRAYSYM, BEGINSYM, CONSTSYM, DIVSYM, DOSYM, ENDSYM,
	IFSYM, INTSYM, MODSYM, OFSYM, PROCSYM, PROGSYM,
	THENSYM, VARSYM, WHILESYM, TERROR
};

int LineNumber = 0;
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
return(TPLUS);
break;
case 2:
return(TMINUS);
break;
case 3:
return(TTIMES);
break;
case 4:
return(TCOMMA);
break;
case 5:
return(TSEMICOLON);
break;
case 6:
return(TCOLON);
break;
case 7:
return(TASSIGN);
break;
case 8:
return(TDDOT);
break;
case 9:
return(TLPAREN);
break;
case 10:
return(TRPAREN);
break;
case 11:
return(TLBRACKET);
break;
case 12:
return(TRBRACKET);
break;
case 13:
return(TEQUAL);
break;
case 14:
return(TNEQUAL);
break;
case 15:
return(TLESS);
break;
case 16:
return(TLESSE);
break;
case 17:
return(TGREAT);
break;
case 18:
return(TGREATE);
break;
case 19:
return(TDOT);
break;
case 20:
return(ARRAYSYM);
break;
case 21:
return(BEGINSYM);
break;
case 22:
return(CONSTSYM);
break;
case 23:
return(DIVSYM);
break;
case 24:
return(DOSYM);
break;
case 25:
return(ENDSYM);
break;
case 26:
return(IFSYM);
break;
case 27:
return(INTSYM);
break;
case 28:
return(MODSYM);
break;
case 29:
return(OFSYM);
break;
case 30:
return(PROCSYM);
break;
case 31:
return(PROGSYM);
break;
case 32:
return(THENSYM);
break;
case 33:
return(VARSYM);
break;
case 34:
return(WHILESYM);
break;
case 35:
return(TIDENT);
break;
case 36:
return(TNUMBER);
break;
case 37:
;
break;
case 38:
LineNumber++;
break;
case 39:
return(TERROR);
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
main()
{
	enum tnumber tn;

	printf("Start of lex\n");
	while ((tn = yylex()) != TEOF) {
		switch (tn) {
		case TIDENT:
		case TNUMBER:
			printf("\t(%2i, %s)\n", tn, yytext); break;
		case TERROR:
			printf("ERROR -- line %d : [%c]\n", LineNumber, yytext[0]); break;
		default:
			printf("\t(%2i, 0)\n", tn);
		}
	}
}

yywrap() { printf("End of Lex\n"); return 1; }

int yyvstop[] = {
0,

39,
0,

37,
39,
0,

38,
0,

9,
39,
0,

10,
39,
0,

3,
39,
0,

1,
39,
0,

4,
39,
0,

2,
39,
0,

19,
39,
0,

36,
39,
0,

6,
39,
0,

5,
39,
0,

15,
39,
0,

13,
39,
0,

17,
39,
0,

35,
39,
0,

11,
39,
0,

12,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

35,
39,
0,

8,
0,

36,
0,

7,
0,

16,
0,

14,
0,

18,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

24,
35,
0,

35,
0,

26,
35,
0,

35,
0,

35,
0,

29,
35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

23,
35,
0,

25,
35,
0,

35,
0,

28,
35,
0,

35,
0,

35,
0,

33,
35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

35,
0,

32,
35,
0,

35,
0,

20,
35,
0,

21,
35,
0,

22,
35,
0,

35,
0,

35,
0,

35,
0,

34,
35,
0,

35,
0,

35,
0,

35,
0,

27,
35,
0,

35,
0,

31,
35,
0,

35,
0,

30,
35,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,6,	1,7,	1,8,	
1,9,	1,10,	1,11,	1,12,	
12,34,	1,13,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,14,	
1,15,	1,16,	1,17,	1,18,	
14,36,	18,39,	1,19,	13,35,	
13,35,	13,35,	13,35,	13,35,	
13,35,	13,35,	13,35,	13,35,	
13,35,	16,37,	16,38,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,20,	0,0,	1,21,	0,0,	
0,0,	0,0,	1,22,	1,23,	
1,24,	1,25,	1,26,	0,0,	
0,0,	0,0,	1,27,	0,0,	
0,0,	0,0,	1,28,	0,0,	
1,29,	1,30,	0,0,	0,0,	
0,0,	1,31,	32,53,	1,32,	
1,33,	2,6,	2,7,	2,8,	
2,9,	2,10,	2,11,	2,12,	
23,42,	27,47,	25,44,	26,46,	
24,43,	28,49,	29,50,	22,41,	
25,45,	27,48,	30,51,	2,14,	
2,15,	2,16,	2,17,	2,18,	
31,52,	33,54,	41,55,	42,56,	
43,57,	44,58,	46,59,	48,60,	
49,61,	51,62,	52,63,	53,64,	
54,65,	55,66,	56,67,	57,68,	
60,69,	62,70,	63,72,	65,73,	
66,74,	62,71,	67,75,	68,76,	
69,77,	70,78,	71,79,	73,80,	
2,20,	77,81,	2,21,	78,82,	
79,83,	81,84,	2,22,	2,23,	
2,24,	2,25,	2,26,	82,85,	
83,86,	85,87,	2,27,	87,88,	
0,0,	0,0,	2,28,	0,0,	
2,29,	2,30,	0,0,	0,0,	
0,0,	2,31,	0,0,	2,32,	
2,33,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
0,0,	0,0,	0,0,	0,0,	
19,40,	0,0,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
19,40,	19,40,	19,40,	19,40,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-81,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+6,
yycrank+0,	0,		yyvstop+8,
yycrank+0,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+14,
yycrank+0,	0,		yyvstop+17,
yycrank+0,	0,		yyvstop+20,
yycrank+0,	0,		yyvstop+23,
yycrank+2,	0,		yyvstop+26,
yycrank+19,	0,		yyvstop+29,
yycrank+3,	0,		yyvstop+32,
yycrank+0,	0,		yyvstop+35,
yycrank+16,	0,		yyvstop+38,
yycrank+0,	0,		yyvstop+41,
yycrank+4,	0,		yyvstop+44,
yycrank+153,	0,		yyvstop+47,
yycrank+0,	0,		yyvstop+50,
yycrank+0,	0,		yyvstop+53,
yycrank+21,	yysvec+19,	yyvstop+56,
yycrank+27,	yysvec+19,	yyvstop+59,
yycrank+21,	yysvec+19,	yyvstop+62,
yycrank+25,	yysvec+19,	yyvstop+65,
yycrank+21,	yysvec+19,	yyvstop+68,
yycrank+27,	yysvec+19,	yyvstop+71,
yycrank+22,	yysvec+19,	yyvstop+74,
yycrank+32,	yysvec+19,	yyvstop+77,
yycrank+24,	yysvec+19,	yyvstop+80,
yycrank+40,	yysvec+19,	yyvstop+83,
yycrank+21,	yysvec+19,	yyvstop+86,
yycrank+41,	yysvec+19,	yyvstop+89,
yycrank+0,	0,		yyvstop+92,
yycrank+0,	yysvec+13,	yyvstop+94,
yycrank+0,	0,		yyvstop+96,
yycrank+0,	0,		yyvstop+98,
yycrank+0,	0,		yyvstop+100,
yycrank+0,	0,		yyvstop+102,
yycrank+0,	yysvec+19,	yyvstop+104,
yycrank+32,	yysvec+19,	yyvstop+106,
yycrank+44,	yysvec+19,	yyvstop+108,
yycrank+38,	yysvec+19,	yyvstop+110,
yycrank+31,	yysvec+19,	yyvstop+112,
yycrank+0,	yysvec+19,	yyvstop+114,
yycrank+50,	yysvec+19,	yyvstop+117,
yycrank+0,	yysvec+19,	yyvstop+119,
yycrank+35,	yysvec+19,	yyvstop+122,
yycrank+52,	yysvec+19,	yyvstop+124,
yycrank+0,	yysvec+19,	yyvstop+126,
yycrank+42,	yysvec+19,	yyvstop+129,
yycrank+53,	yysvec+19,	yyvstop+131,
yycrank+41,	yysvec+19,	yyvstop+133,
yycrank+51,	yysvec+19,	yyvstop+135,
yycrank+60,	yysvec+19,	yyvstop+137,
yycrank+53,	yysvec+19,	yyvstop+139,
yycrank+44,	yysvec+19,	yyvstop+141,
yycrank+0,	yysvec+19,	yyvstop+143,
yycrank+0,	yysvec+19,	yyvstop+146,
yycrank+59,	yysvec+19,	yyvstop+149,
yycrank+0,	yysvec+19,	yyvstop+151,
yycrank+62,	yysvec+19,	yyvstop+154,
yycrank+52,	yysvec+19,	yyvstop+156,
yycrank+0,	yysvec+19,	yyvstop+158,
yycrank+55,	yysvec+19,	yyvstop+161,
yycrank+43,	yysvec+19,	yyvstop+163,
yycrank+56,	yysvec+19,	yyvstop+165,
yycrank+51,	yysvec+19,	yyvstop+167,
yycrank+65,	yysvec+19,	yyvstop+169,
yycrank+68,	yysvec+19,	yyvstop+171,
yycrank+56,	yysvec+19,	yyvstop+173,
yycrank+0,	yysvec+19,	yyvstop+175,
yycrank+70,	yysvec+19,	yyvstop+178,
yycrank+0,	yysvec+19,	yyvstop+180,
yycrank+0,	yysvec+19,	yyvstop+183,
yycrank+0,	yysvec+19,	yyvstop+186,
yycrank+72,	yysvec+19,	yyvstop+189,
yycrank+75,	yysvec+19,	yyvstop+191,
yycrank+79,	yysvec+19,	yyvstop+193,
yycrank+0,	yysvec+19,	yyvstop+195,
yycrank+63,	yysvec+19,	yyvstop+198,
yycrank+66,	yysvec+19,	yyvstop+200,
yycrank+75,	yysvec+19,	yyvstop+202,
yycrank+0,	yysvec+19,	yyvstop+204,
yycrank+71,	yysvec+19,	yyvstop+207,
yycrank+0,	yysvec+19,	yyvstop+209,
yycrank+86,	yysvec+19,	yyvstop+212,
yycrank+0,	yysvec+19,	yyvstop+214,
0,	0,	0};
struct yywork *yytop = yycrank+275;
struct yysvf *yybgin = yysvec+1;
unsigned char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,'A' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
unsigned char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*
 * *****************************************************************
 * *                                                               *
 * *    Copyright (c) Digital Equipment Corporation, 1991, 1998    *
 * *                                                               *
 * *   All Rights Reserved.  Unpublished rights  reserved  under   *
 * *   the copyright laws of the United States.                    *
 * *                                                               *
 * *   The software contained on this media  is  proprietary  to   *
 * *   and  embodies  the  confidential  technology  of  Digital   *
 * *   Equipment Corporation.  Possession, use,  duplication  or   *
 * *   dissemination of the software and media is authorized only  *
 * *   pursuant to a valid written license from Digital Equipment  *
 * *   Corporation.                                                *
 * *                                                               *
 * *   RESTRICTED RIGHTS LEGEND   Use, duplication, or disclosure  *
 * *   by the U.S. Government is subject to restrictions  as  set  *
 * *   forth in Subparagraph (c)(1)(ii)  of  DFARS  252.227-7013,  *
 * *   or  in  FAR 52.227-19, as applicable.                       *
 * *                                                               *
 * *****************************************************************
 */
/*
 * HISTORY
 */
/*
 * @(#)$RCSfile: ncform,v $
 */
int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
unsigned char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
unsigned char yysbuf[YYLMAX];
unsigned char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	unsigned char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
            if (yylastch >= yytext + (YYLMAX - 1)) {
                fprintf(yyout, "Maximum token length exceeded\n");
                yytext[YYLMAX - 1] = 0;
                return 0;
            }
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( yyt > yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if(yyt < yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
                if (yyleng >= (YYLMAX - 1)) {
                    fprintf(yyout, "Maximum token length exceeded\n");
                    yytext[YYLMAX - 1] = 0;
                    return 0;
                }
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
